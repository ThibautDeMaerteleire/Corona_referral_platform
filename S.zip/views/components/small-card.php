<div href="/<?=$url?>" class="small-card">
    <img class="small-card_img" src="/assets/images/<?=$img?>" alt="<?=$title?>">
    <h4 class="small-card_title"><?=$title?></h4>
    <p class="small-card_text"><?=$text?></p>
    <a class="small-card_link" href="<?=$url?>">Read more</a>
</div>
