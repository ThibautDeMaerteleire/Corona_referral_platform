import {SmallCards} from './small-cards.js';

export const LaunchComponents = () => {
  new SmallCards();
};