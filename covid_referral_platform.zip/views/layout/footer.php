<footer class="bg-flashy-green container-fluid">
    <section class="d-flex align-items-center justify-content-between">
        <nav class="d-flex align-items-center justify-content-between">
            <a href="/gebruiksvoorwaarden.php">Gebruiksvoorwaarden</a>
            <a href="/privacy.php">Privacy</a>
            <a href="/cookies.php">Cookies</a>
            <a href="/contact.php">Contact</a>
        </nav>
        <div class="socialmedia d-flex align-items-end justify-content-between">
            <a rel="norefferer noopener" target="_blank" href="https://facebook.com/corona-referral-platform"><i class="fab fa-facebook-f"></i></a>
            <a rel="norefferer noopener" target="_blank" href="https://linkedin.com/corona-referral-platform"><i class="fab fa-linkedin-in"></i></a>
            <a rel="norefferer noopener" target="_blank" href="https://twitter.com/corona-referral-platform"><i class="fab fa-twitter"></i></a>
            <a rel="norefferer noopener" target="_blank" href="https://youtube.com/corona-referral-platform"><i class="fab fa-youtube"></i></a>
            <a rel="norefferer noopener" target="_blank" href="https://github.com/pgmgent-thibdema/Corona_referral_platform"><i class="fab fa-github"></i></a>

        </div>
    </section>
    <hr>
    <p>Corona Referral Platform 2020 - Thibaut De Maerteleire</p>
</footer>