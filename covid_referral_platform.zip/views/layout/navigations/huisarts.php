<nav class="header_nav d-flex justify-content-between align-items-center container-fluid ">
    <ul class="d-flex align-items-center">
        <li><a href="/Huisarts/index.php">Dashboard</a></li>
        <li><a href="/Huisarts/addpatient.php">Patiënt toevoegen</a></li>
        <li><a href="/Huisarts/patienten.php">Patiënten</a></li>
        <li><a href="/Huisarts/positive_cases.php">Positieve tests</a></li>
        <li><a href="/Huisarts/tests_progress.php">Tests in progress</a></li>
    </ul>
    <form action="/Huisarts/searchpatients.php" method="POST">
        <input class="form-control" placeholder="Search ..." type="text">
    </form>
</nav>
